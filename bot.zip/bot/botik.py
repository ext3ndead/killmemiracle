import logging
import requests
import uuid
from datetime import datetime
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
    CallbackQueryHandler
)

from config import TELEGRAM_BOT_TOKEN, CRYPTO_API_URL, SUPPORTED_CURRENCIES

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# Your card details
CARD_NUMBER = '2200 7013 6400 4694'
MINIMUM_AMOUNT = 5000  # Minimum exchange amount in RUB
COMMISSION_RATE = 0.03  # 3% commission

# Conversation states
SELECTING_CRYPTO, ENTERING_AMOUNT, PAYMENT_CONFIRMATION, WALLET_ADDRESS = range(4)

async def get_rates():
    """Fetch current cryptocurrency rates in USD."""
    params = {
        'ids': ','.join(SUPPORTED_CURRENCIES),
        'vs_currencies': 'usd'
    }
    response = requests.get(CRYPTO_API_URL, params=params)
    rates = response.json()
    
    # Add RUB rates with commission for exchange functionality
    rub_params = {
        'ids': ','.join(SUPPORTED_CURRENCIES),
        'vs_currencies': 'rub'
    }
    rub_response = requests.get(CRYPTO_API_URL, params=rub_params)
    rub_rates = rub_response.json()
    
    # Apply 3% commission to RUB rates
    for currency in rub_rates:
        if 'rub' in rub_rates[currency]:
            rub_rates[currency]['rub'] *= (1 + COMMISSION_RATE)
        else:
            logging.warning(f"No RUB rate found for currency: {currency}")
    
    return {'usd': rates, 'rub': rub_rates}



async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /start is issued."""
    keyboard = [['/rates', '/exchange'], ['Support']]


    reply_markup = ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)

    await update.message.reply_text(
        "Добро пожаловать в Crypto Exchange Bot!\n\n"
        "Доступные команды:\n"
        "/rates - Текущие курсы криптовалют\n"
        "/exchange - Обмен валюты",

        reply_markup=reply_markup
    )

async def rates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send current cryptocurrency rates in RUB with commission."""
    rates_data = await get_rates()
    message = "Текущие курсы (USD):\n"

    for currency, rate in rates_data['usd'].items():
        message += f"{currency.capitalize()}: ${rate['usd']:.2f}\n"


    keyboard = [['Main Menu']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text(message, reply_markup=reply_markup)


async def start_exchange(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Start the exchange process."""
    # Show available cryptocurrencies
    rates_data = await get_rates()
    crypto_options = "\n".join(
        f"{i+1}. {currency.capitalize()} (₽{rates_data['rub'][currency]['rub']:.2f})"
        for i, currency in enumerate(SUPPORTED_CURRENCIES)
    )

    
    keyboard = [['Main Menu']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text(
        f"Выберите криптовалюту для обмена:\n{crypto_options}\n\n"
        "Пожалуйста, введите номер вашего выбора:",

        reply_markup=reply_markup
    )

    
    return SELECTING_CRYPTO

async def select_crypto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle cryptocurrency selection."""
    try:
        rates_data = await get_rates()
        selected_index = int(update.message.text) - 1
        selected_currency = SUPPORTED_CURRENCIES[selected_index]
        context.user_data['selected_currency'] = selected_currency
        context.user_data['selected_rate'] = rates_data['rub'][selected_currency]['rub']

        
        await update.message.reply_text(
            f"Введите сумму в RUB, которую хотите обменять на {selected_currency.capitalize()}.\n"
            f"Минимальная сумма: ₽{MINIMUM_AMOUNT:.2f}"
        )
        
        return ENTERING_AMOUNT
    except (ValueError, IndexError):

        keyboard = [['Main Menu']]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        await update.message.reply_text("Неверный выбор. Пожалуйста, попробуйте снова.", reply_markup=reply_markup)


        return SELECTING_CRYPTO

async def enter_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle amount input."""
    try:
        amount_rub = float(update.message.text)
        
        # Validate minimum amount
        if amount_rub < MINIMUM_AMOUNT:
            keyboard = [['Main Menu']]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            await update.message.reply_text(f"Минимальная сумма обмена ₽{MINIMUM_AMOUNT:.2f}", reply_markup=reply_markup)


            return ENTERING_AMOUNT
        
        context.user_data['amount_rub'] = amount_rub
        
        # Calculate amounts
        commission = amount_rub * COMMISSION_RATE
        total_amount = amount_rub - commission
        crypto_amount = total_amount / context.user_data['selected_rate']
        
        context.user_data['commission'] = commission
        context.user_data['crypto_amount'] = crypto_amount
        
        # Display transaction details
        await update.message.reply_text(
            f"Детали транзакции:\n\n"

            f"Выбранная валюта: {context.user_data['selected_currency'].capitalize()}\n"
            f"Сумма обмена: ₽{amount_rub:.2f}\n"
            f"Комиссия (3%): ₽{commission:.2f}\n"
            f"Сумма для обмена: ₽{total_amount:.2f}\n"
            f"Вы получите: {crypto_amount:.8f} {context.user_data['selected_currency']}\n\n"
            f"Для завершения обмена, пожалуйста, переведите ₽{amount_rub:.2f} на:\n"
            f"Номер карты: {CARD_NUMBER}\n\n"
            "После перевода, пожалуйста, введите 'paid' для подтверждения."

        )
        
        return PAYMENT_CONFIRMATION
    except ValueError:
        keyboard = [['Main Menu']]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        await update.message.reply_text("Неверная сумма. Пожалуйста, введите число.", reply_markup=reply_markup)


        return ENTERING_AMOUNT

async def payment_confirmation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle payment confirmation."""
    if update.message.text.lower() == 'paid':
        keyboard = [['Main Menu']]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        await update.message.reply_text("Пожалуйста, укажите адрес вашего криптовалютного кошелька:", reply_markup=reply_markup)


        return WALLET_ADDRESS
    else:
        keyboard = [['Main Menu']]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        await update.message.reply_text("Платеж не подтвержден. Транзакция отменена.", reply_markup=reply_markup)


        return ConversationHandler.END

async def wallet_address(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle wallet address input."""
    wallet_address = update.message.text
    
    # Log transaction
    log_transaction(
        str(uuid.uuid4())[:8],
        update.effective_user.id,
        context.user_data['selected_currency'],
        context.user_data['amount_rub'],
        context.user_data['commission'],
        context.user_data['crypto_amount'],
        wallet_address
    )
    
    keyboard = [['Main Menu']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text(
        f"Транзакция успешно завершена!\n"

        f"{context.user_data['crypto_amount']:.8f} {context.user_data['selected_currency']} "
        f"будет отправлено на ваш кошелек.",

        reply_markup=reply_markup
    )

    
    # Clear user data
    context.user_data.clear()
    
    return ConversationHandler.END

async def support(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Provide 24/7 support information."""
    keyboard = [['Main Menu']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text(
        "Для круглосуточной поддержки, пожалуйста, свяжитесь с: @cryptoinvoice_help",

        reply_markup=reply_markup
    )

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):

    """Cancel the conversation."""
    keyboard = [['Main Menu']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Transaction cancelled.", reply_markup=reply_markup)
    context.user_data.clear()
    return ConversationHandler.END

async def main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Return to main menu."""
    keyboard = [['/rates', '/exchange'], ['Support']]

    reply_markup = ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)
    await update.message.reply_text(
        "Добро пожаловать в Crypto Exchange Bot!\n\n"
        "Доступные команды:\n"
        "/rates - Текущие курсы криптовалют\n"
        "/exchange - Обмен валюты",

        reply_markup=reply_markup
    )

def log_transaction(transaction_id, user_id, currency, amount_rub, commission, crypto_amount, wallet_address):

    """Log transaction to botik.txt."""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_entry = (
        f"{timestamp},{transaction_id},{user_id},{currency},"
        f"{amount_rub:.2f},{commission:.2f},{crypto_amount:.8f},{wallet_address}\n"
    )
    with open('botik.txt', 'a') as f:
        f.write(log_entry)

async def wait_for_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Wait for user message."""
    try:
        message = await context.bot.wait_for(
            'message',
            timeout=300,  # 5 minutes timeout
            chat_id=update.effective_chat.id
        )
        return message
    except asyncio.TimeoutError:
        await update.message.reply_text("Время ожидания сообщения истекло. Пожалуйста, попробуйте снова.")

        return None

def main():
    """Start the bot."""
    application = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()

    
    # Create conversation handler for exchange
    exchange_handler = ConversationHandler(
        entry_points=[CommandHandler('exchange', start_exchange)],
        states={
            SELECTING_CRYPTO: [MessageHandler(filters.TEXT & ~filters.COMMAND, select_crypto)],
            ENTERING_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_amount)],
            PAYMENT_CONFIRMATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, payment_confirmation)],
            WALLET_ADDRESS: [MessageHandler(filters.TEXT & ~filters.COMMAND, wallet_address)]
        },
        fallbacks=[CommandHandler('cancel', cancel)]
    )
    
    # Register command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("rates", rates))
    application.add_handler(MessageHandler(filters.Text("Main Menu"), main_menu))
    application.add_handler(MessageHandler(filters.Text("Support"), support))
    application.add_handler(exchange_handler)


    
    # Start the bot
    application.run_polling()

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())
