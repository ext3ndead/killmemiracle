# Telegram Bot Token
# Get your token from @BotFather on Telegram
TELEGRAM_BOT_TOKEN = '7548502560:AAGTb5JPVbWiG7RTNoL-8sFopNbQ4p4tgWQ'  # Replace with your actual token

# Cryptocurrency API Configuration
CRYPTO_API_URL = 'https://api.coingecko.com/api/v3/simple/price'
SUPPORTED_CURRENCIES = ['bitcoin', 'ethereum', 'litecoin', 'tether']

# Instructions:
# 1. Open Telegram and search for @BotFather
# 2. Start a chat and use /newbot command
# 3. Follow instructions to create a new bot
# 4. Copy the token provided by BotFather
# 5. Replace 'YOUR_TELEGRAM_BOT_TOKEN_HERE' with your actual token
